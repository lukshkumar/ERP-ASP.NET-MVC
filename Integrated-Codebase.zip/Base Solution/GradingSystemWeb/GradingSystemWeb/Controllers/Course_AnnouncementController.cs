﻿using CourseAnnouncementMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mail;
using System.Web.Mvc;

/*
 The data of webapi has been fetched and configured using GlobalVariable.cs which can not be configured into this .NET CORE project,
and if I try to do so, It gives me a runtime exception, therefore will have to change the way it reads from an API.

 * */
namespace CourseAnnouncementMVC.Controllers
{

    /*
    public static class GlobalVariable
    {
        public static HttpClient WebApiClient = new HttpClient();



        static GlobalVariable()
        {
            WebApiClient.BaseAddress = new Uri("http://localhost:53620/api/");
            WebApiClient.DefaultRequestHeaders.Clear();
           // WebApiClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

    }
    public class Course_AnnouncementController : Controller
    {
        public static HttpClient WebApiClient = new HttpClient();
        public void GlobalVariable()
        {

            WebApiClient.BaseAddress = new Uri("http://localhost:53620/api/");
            WebApiClient.DefaultRequestHeaders.Clear();
            //WebApiClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        public int rollId = 1;
        // GET: Course_Announcement
        public ActionResult Index()
        {
            /* IEnumerable<mvcCourseAnnoucementModel> courseList;
             HttpResponseMessage response = GlobalVariable.WebApiClient.GetAsync("Course_Announcement").Result;
             courseList = response.Content.ReadAsAsync<IEnumerable<mvcCourseAnnoucementModel>>().Result;
             return View(courseList); 
            
            //HttpResponseMessage response = GlobalVariable.WebApiClient.GetAsync("student/" + rollId.ToString()).Result;
          
            
            return View(response.Content.ReadAsAsync<mvcStudentModel>().Result);
            
        }


        public ActionResult AddCourseAnnouncement(int id=0)
        {
            if(id==0)
            {
                return View();
            }
            else
            {
                HttpResponseMessage response = GlobalVariable.WebApiClient.GetAsync("Course_Announcement/"+id.ToString()).Result;
                return View(response.Content.ReadAsAsync<mvcCourseAnnoucementModel>().Result);
                
            }
        }

        public ActionResult ViewCourseAnnouncement()
        {
            IEnumerable<mvcCourseAnnoucementModel> courseList;
            HttpResponseMessage response = GlobalVariable.WebApiClient.GetAsync("Course_Announcement").Result;
            courseList = response.Content.ReadAsAsync<IEnumerable<mvcCourseAnnoucementModel>>().Result;

            //get batch of student
          
            HttpResponseMessage res = GlobalVariable.WebApiClient.GetAsync("student/" +rollId.ToString()).Result;
            mvcStudentModel stud = res.Content.ReadAsAsync<mvcStudentModel>().Result;
            ViewBag.studentBatch = stud.batch;
            return View(courseList);
        }

        public ActionResult EditCourseAnnouncement()
        {
            IEnumerable<mvcCourseAnnoucementModel> courseList;
            HttpResponseMessage response = GlobalVariable.WebApiClient.GetAsync("Course_Announcement").Result;
            courseList = response.Content.ReadAsAsync<IEnumerable<mvcCourseAnnoucementModel>>().Result;
            return View(courseList);
        }

        public String resAddress;
        [HttpPost]
        public ActionResult AddCourseAnnouncement(mvcCourseAnnoucementModel courseAnnouncement)
        {
            IEnumerable<mvcStudentModel> stud;
            HttpResponseMessage res = GlobalVariable.WebApiClient.GetAsync("student/").Result; 
           stud = res.Content.ReadAsAsync<IEnumerable<mvcStudentModel>>().Result;
           
            foreach(var item in stud)
            {
                if(item.batch==courseAnnouncement.Batch)
                {
                   String resipientAddress = item.email;
                    
                    var senderEmail = new MailAddress("kzubaid23@gmail.com", "FAST NU");
                    var receiverEmail = new MailAddress(resipientAddress, "Student");
                    var password = "ubaid123";
                    var sub = courseAnnouncement.title;
                    var body = courseAnnouncement.details;
                    
                    var smtp = new SmtpClient
                    {
                        Host = "smtp.gmail.com",
                        Port = 587,
                        EnableSsl = true,

                        DeliveryMethod = SmtpDeliveryMethod.Network,
                        UseDefaultCredentials = false,
                        Credentials = new NetworkCredential(senderEmail.Address, password)
                    };
                    using (var mess = new MailMessage(senderEmail, receiverEmail)
                    {
                        Subject = sub,
                        Body = body
                    })
                    {
                        smtp.Send(mess);
                    }
                }
            }
          
            if (courseAnnouncement.id == 0)
            {
                HttpResponseMessage response = GlobalVariable.WebApiClient.PostAsJsonAsync("Course_Announcement", courseAnnouncement).Result;
            }
            else
            {
                HttpResponseMessage response = GlobalVariable.WebApiClient.PutAsJsonAsync("Course_Announcement/" + courseAnnouncement.id, courseAnnouncement).Result;
            }

            return RedirectToAction("Index");
        }

       
        public ActionResult Delete(int id)
        {

            HttpResponseMessage response = GlobalVariable.WebApiClient.DeleteAsync("Course_Announcement/"+id.ToString()).Result;
            return RedirectToAction("EditCourseAnnouncement");
        }
    }
    */
}