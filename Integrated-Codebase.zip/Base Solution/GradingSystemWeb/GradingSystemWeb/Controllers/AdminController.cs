﻿using AdminFacultyPortal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
//using Microsoft.AspNetCore.Mvc;

/*
 -Ashir project Session is not working with .net core 2 that is being used by Ali. This Session is in HttpContext Controller in System.web but I am unable to find its solution.
Reference: https://stackoverflow.com/questions/50847326/reference-to-type-claims-it-is-defined-in-system-web-but-it-could-not-be-f
This is the way i figured out that allows us to use Session from httpcontext in .net core which is way different from .net framework (the way ashir has used)
https://www.c-sharpcorner.com/article/how-to-use-session-in-asp-net-core/

 */


namespace GradingSystemWeb.Controllers
{
    /*
    public class AdminController : Controller
    {
        string Baseurl = "http://localhost:59555/";


        public ActionResult AttendanceHome()
        {
            IEnumerable<Faculty> faculty = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                //HTTP GET
                var responseTask = client.GetAsync("api/Attendance/getfaculty");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<Faculty>>();
                    readTask.Wait();

                    faculty = readTask.Result;
                }
                else //web api sent error response 
                {
                    //log response status here..

                    faculty = Enumerable.Empty<Faculty>();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }
            return View(faculty);
        }

        [HttpPost]
        public ActionResult AdminAttendanceAccess(FormCollection formCollection)
        {
            Session.Clear();
            Session["facultyId"] = formCollection["facultyId"];
            return RedirectToAction("Attendance");
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Attendance()
        {
            ViewBag.Message = "Your Attendance page.";

            IEnumerable<Course> course = null;
            IEnumerable<Section_Offered> section = null;
            IEnumerable<Student> student = null;
            IEnumerable<Lecture_Attend> lecture_attend = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                //HTTP GET
                var responseTask = client.GetAsync("api/Attendance/getcourses/" + Session["facultyId"]);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<Course>>();
                    readTask.Wait();

                    course = readTask.Result;
                }
                else //web api sent error response 
                {
                    //log response status here..

                    course = Enumerable.Empty<Course>();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }

            if (Session["courseId"] == null)
            {
                Session["courseId"] = course.First<Course>().code;
            }


            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                //HTTP GET
                var responseTask = client.GetAsync("api/Attendance/getsection/" + Session["courseId"] + "/" + Session["facultyId"]);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<Section_Offered>>();
                    readTask.Wait();

                    section = readTask.Result;
                }
                else //web api sent error response 
                {
                    //log response status here..

                    section = Enumerable.Empty<Section_Offered>();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }


            if (Session["sectionId"] == null)
            {
                Session["sectionId"] = section.First<Section_Offered>().id;
            }

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                //HTTP GET
                var responseTask = client.GetAsync("api/Attendance/getstudent/" + Session["sectionId"]);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<Student>>();
                    readTask.Wait();

                    student = readTask.Result;
                }
                else //web api sent error response 
                {
                    //log response status here..

                    student = Enumerable.Empty<Student>();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                //HTTP GET
                var responseTask = client.GetAsync("api/Attendance/getLectures/" + Session["sectionId"]);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<Lecture_Attend>>();
                    readTask.Wait();

                    lecture_attend = readTask.Result;
                }
                else //web api sent error response 
                {
                    //log response status here..

                    lecture_attend = Enumerable.Empty<Lecture_Attend>();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }



            AttendanceViewModel attendanceViewModel = new AttendanceViewModel();
            attendanceViewModel.course = course;
            attendanceViewModel.section = section;
            attendanceViewModel.student = student;
            attendanceViewModel.lecture_attend = lecture_attend;


            return View(attendanceViewModel);
        }

        [HttpPost]
        public ActionResult Submit(FormCollection formCollection)
        {
            List<Attendance> attendance = new List<Attendance>();
            foreach (var key in formCollection.AllKeys)
            {
                attendance.Add(new Attendance() { id = Convert.ToInt32(key), status = formCollection[key] });
            }

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);

                //HTTP POST
                var postTask = client.PostAsJsonAsync<List<Attendance>>("api/Attendance/updateattendance", attendance);
                postTask.Wait();
                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Attendance");
                }
            }

            return RedirectToAction("Attendance");
        }

        [HttpGet]
        //        [Route("Home/DeleteLecture/{lecId}")]
        public ActionResult DeleteLecture(int lecId)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                //HTTP Delete
                var responseTask = client.DeleteAsync("api/Attendance/deleteLecture/" + Convert.ToInt64(lecId));
                responseTask.Wait();

                var result = responseTask.Result;
                if (!result.IsSuccessStatusCode)
                {
                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }

            return RedirectToAction("Attendance");
        }

        [HttpGet]
        //        [Route("Home/DeleteLecture/{lecId}")]
        public ActionResult ChangeCourse(string courseId)
        {
            Session["courseId"] = courseId;
            Session["sectionId"] = null;
            return Json(new { success = true, responseText = "Session Updated Successfully!" }, JsonRequestBehavior.AllowGet);

        }

        [HttpGet]
        //        [Route("Home/DeleteLecture/{lecId}")]
        public ActionResult ChangeSection(int sectionId)
        {
            Session["sectionId"] = sectionId;
            return Json(new { success = true, responseText = "Session Updated Successfully!" }, JsonRequestBehavior.AllowGet);

        }

        [HttpPost]
        public ActionResult AddLecture(FormCollection formCollection)
        {
            Lecture addLecture = new Lecture();
            addLecture.date_time = Convert.ToDateTime(formCollection["date"]);
            addLecture.duration = Convert.ToInt16(formCollection["duration"]);
            addLecture.section_offered_id = Convert.ToInt32(Session["sectionId"]);
            addLecture.defaultValue = formCollection["defaultValue"];

            // completed Till here

            using (var client = new HttpClient())
            {

                client.BaseAddress = new Uri(Baseurl);

                //HTTP POST
                var postTask = client.PostAsJsonAsync<Lecture>("api/Attendance/AddLecture", addLecture);
                // error
                postTask.Wait();
                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Attendance");
                }
            }

            return RedirectToAction("Attendance");
        }
    }
    */
}
