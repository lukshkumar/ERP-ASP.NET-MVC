﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Collections.Specialized;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Microsoft.AspNetCore.Http;
using Json.Net;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace GradingSystemWeb.Controllers
{
    public class FacultyController : Controller
    {
        // GET: /<controller>/
        public IActionResult Index()
        {
            
                return View("Login");
            
        }

        public IActionResult Login()
        {
            return View();
        }


        [HttpPost]
        public ActionResult LoginSubmitted()
        {
            string email = HttpContext.Request.Form["email"];
            string password = ComputeSha256Hash(HttpContext.Request.Form["password"]);

            string response_final = "";

            using (var client= new WebClient())
            {
                var data = new NameValueCollection();
                data["email"] = email;
                data["password"] =password;

                var response = client.UploadValues("https://localhost:5001/api/Home/loginFaculty", "POST", data);
                response_final= Encoding.UTF8.GetString(response);
                
            }

            return Content(response_final);
        }

        static string ComputeSha256Hash(string rawData)
        {
            // Create a SHA256   
            using (SHA256 sha256Hash = SHA256.Create())
            {
                // ComputeHash - returns byte array  
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));

                // Convert byte array to a string   
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

    }
}
