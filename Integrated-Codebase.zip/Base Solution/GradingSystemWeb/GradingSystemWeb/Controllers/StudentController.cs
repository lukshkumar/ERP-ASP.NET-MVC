﻿using AdminFacultyPortal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;

using System.Web.Mvc;
using Microsoft.AspNetCore.Http;

/*
 -Ashir project Session is not working with .net core 2 that is being used by Ali. This Session is in HttpContext Controller in System.web but I am unable to find its solution.
Reference: https://stackoverflow.com/questions/50847326/reference-to-type-claims-it-is-defined-in-system-web-but-it-could-not-be-f
This is the way i figured out that allows us to use Session from httpcontext in .net core which is way different from .net framework (the way ashir has used)
https://www.c-sharpcorner.com/article/how-to-use-session-in-asp-net-core/

 */

namespace GradingSystemWeb.Controllers
{
    /*
    public class StudentController : Controller
    {
        string Baseurl = "http://localhost:59555/";

        public ActionResult StudentAttendanceLogin()
        {
            Session.Clear();
            return View();
        }
        [HttpPost]
        public ActionResult StudentAttendanceLogin(StudentLogin login)
        {
            if (ModelState.IsValid) // this is check validity
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(Baseurl);

                    //HTTP POST
                    var postTask = client.PostAsJsonAsync<StudentLogin>("api/Attendance/StudentLogin", login);
                    postTask.Wait();
                    var result = postTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<Student>();
                        if (readTask.Result != null)
                        {
                            Session["studentRollno"] = readTask.Result.roll;
                            return RedirectToAction("Attendance");
                        }
                        else
                        {
                            ViewBag.ErrorMessage = "Invalid Username or Password";
                        }
                    }
                }
            }
            return View(login);
        }

        public ActionResult Attendance()
        {
            if (Session["studentRollno"] == null)
            {
                return RedirectToAction("StudentAttendanceLogin");
            }
            ViewBag.Message = "Student Attendance page.";

            IEnumerable<Semester> semester = null;
            StudentAttendanceData studentAttendanceData = new StudentAttendanceData();

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                //HTTP GET
                var responseTask = client.GetAsync("api/Attendance/getStudentSemester/" + Session["studentRollno"]);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<Semester>>();
                    readTask.Wait();

                    semester = readTask.Result;
                }
                else //web api sent error response 
                {
                    //log response status here..

                    semester = Enumerable.Empty<Semester>();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }

            

            if (semester.Count() > 0)
            {
                if( Session["std_sem_id"] == null)
                {
                    Session["std_sem_id"] = semester.First<Semester>().id;
                }
            }


            
            if (Session["std_sem_id"] != null)
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(Baseurl);
                    //HTTP GET
                    var responseTask = client.GetAsync("api/Attendance/getStudentAttendance/" + Session["studentRollno"] + "/" + Session["std_sem_id"]);
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<StudentAttendanceData>();
                        readTask.Wait();

                        studentAttendanceData = readTask.Result;
                    }
                    else //web api sent error response 
                    {
                        //log response status here..

                        studentAttendanceData = new StudentAttendanceData();

                        ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                    }
                }
            }

            studentAttendanceData.semester = semester;
            return View(studentAttendanceData);
        }
        [HttpGet]
        public ActionResult ChangeSemester(int semId)
        {
            Session["std_sem_id"] = semId;
            return Json(new { success = true, responseText = "Semester Updated Successfully!" }, JsonRequestBehavior.AllowGet);

        }
    }
    */
}
