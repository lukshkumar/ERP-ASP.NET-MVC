﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AdminFacultyPortal.Models
{
    public class Lecture
    {
        public int id { get; set; }
        public int duration { get; set; }
        public DateTime date_time { get; set; }
        public int section_offered_id { get; set; }
        public string defaultValue { get; set; }
        public Lecture()
        {
            defaultValue = "P";
        }
        public Lecture(int lecture_id, DateTime date, int sectionOffered_id)
        {
            this.id = 0;
            this.date_time = DateTime.Now;
            this.section_offered_id = 0;
        }
    }
}