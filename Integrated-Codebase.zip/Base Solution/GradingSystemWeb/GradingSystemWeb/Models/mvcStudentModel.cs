﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CourseAnnouncementMVC.Models
{
    public class mvcStudentModel
    {
        public int id { get; set; }

        [Required]
        [StringLength(50)]
        public string roll { get; set; }

        [Required]
        [StringLength(50)]
        public string full_name { get; set; }

        [Required]
        [StringLength(50)]
        public string cnic { get; set; }

        [Required]
        [StringLength(50)]
        public string batch { get; set; }

        public int credits_attempted { get; set; }

        public int credits_earned { get; set; }

        [Required]
        [StringLength(50)]
        public string email { get; set; }
    }
}