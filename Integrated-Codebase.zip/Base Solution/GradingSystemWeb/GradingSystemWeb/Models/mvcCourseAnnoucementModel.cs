﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace CourseAnnouncementMVC.Models
{
    public class mvcCourseAnnoucementModel
    {
        public int id { get; set; }

        [StringLength(50)]
        public string title { get; set; }

        [Column(TypeName = "text")]
        public string details { get; set; }

        public int course_offered_id { get; set; }

        public int faculty_id { get; set; }

        [Required]
        [StringLength(50)]
        public string Batch { get; set; }
    }
}