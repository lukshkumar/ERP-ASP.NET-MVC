﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AdminFacultyPortal.Models
{
    public class Course_Offered
    {
        public int id { get; set; }
        public int session_id { get; set; }
        public int course_id { get; set; }

        public Course_Offered()
        {

        }
        public Course_Offered(int courseOffered_id, int session_id, int course_id)
        {
            this.id = 0;
            this.session_id = 0;
            this.course_id = 0;
        }
    }
}