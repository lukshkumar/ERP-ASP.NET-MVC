﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AdminFacultyPortal.Models
{
    public class StudentAttendanceData
    {
        public IEnumerable<Semester> semester { get; set; }
        public IEnumerable<Course> courses { get; set; }
        public List<List<StudentAttendance>> attendance { get; set; }
    }
}