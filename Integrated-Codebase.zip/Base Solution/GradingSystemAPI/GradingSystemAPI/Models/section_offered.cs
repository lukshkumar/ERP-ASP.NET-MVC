﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GradingSystemAPI.Models
{
    public class Section_Offered
    {
        public int id { get; set; }
        public int faculty_id { get; set; }
        public int course_offered_id { get; set; }
        public Section_Offered()
        {

        }

        public Section_Offered(int section_id, int faculty_id, int courseOffered_id)
        {
            this.id = 0;
            this.faculty_id = 0;
            this.course_offered_id = 0;
        }
    }
}