﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GradingSystemAPI.Models
{
    public class Lecture_Attend
    {
        public Lecture lecture { get; set; }
        public List<Attendance> attend { get; set; }

        public Lecture_Attend(Lecture lecture, List<Attendance> attendance)
        {
            this.lecture = lecture;
            this.attend = attendance;
        }
    }
}