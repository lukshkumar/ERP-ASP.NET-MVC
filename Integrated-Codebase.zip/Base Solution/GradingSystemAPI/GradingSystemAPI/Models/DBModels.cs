namespace CourseAnnouncement.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class DBModels : DbContext
    {
        public DBModels()
            : base("name=DBModels")
        {
        }

        public virtual DbSet<Course_Announcement> Course_Announcement { get; set; }
        /*
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Course_Announcement>()
                .Property(e => e.title)
                .IsUnicode(false);

            modelBuilder.Entity<Course_Announcement>()
                .Property(e => e.details)
                .IsUnicode(false);

            modelBuilder.Entity<Course_Announcement>()
                .Property(e => e.Batch)
                .IsUnicode(false);
        }
        */
    }
}
