﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GradingSystemAPI.Models
{
    public class Course_Registered
    {
        public int id { get; set; }
        public int student_id { get; set; }
        public int course_offered_id { get; set; }
        public int section_offered_id { get; set; }

        public Course_Registered() { }
    }
}