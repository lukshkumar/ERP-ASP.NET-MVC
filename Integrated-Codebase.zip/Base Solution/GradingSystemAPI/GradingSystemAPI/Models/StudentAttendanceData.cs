﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GradingSystemAPI.Models
{
    public class StudentAttendanceData
    {
        public List<Course> courses { get; set; }
        public List<List<StudentAttendance>> attendance { get; set; }
        public StudentAttendanceData()
        {
            attendance = new List<List<StudentAttendance>>();
        }
    }
}