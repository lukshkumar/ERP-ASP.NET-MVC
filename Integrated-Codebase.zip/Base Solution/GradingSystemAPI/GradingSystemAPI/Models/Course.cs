﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GradingSystemAPI.Models
{
    public class Course
    {
        public int id { get; set; }
        public string code { get; set; }
        public string name { get; set; }
        public int credit_hours { get; set; }
        public string type { get; set; }

        public Course() { }
    }
}