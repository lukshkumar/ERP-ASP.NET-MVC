﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GradingSystemAPI.Models
{
    public class Attendance
    {
        public int id { get; set; }
        public string status { get; set; }
        public int lecture_id { get; set; }
        public int student_id { get; set; }

        public string student_roll { get; set; }

        public Attendance() { }
    }
}