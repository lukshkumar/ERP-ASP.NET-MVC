﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GradingSystemAPI.Models
{
    public class Session
    {
        public int id { get; set; }
        public int program_id { get; set; }
        public int semester_id { get; set; }
        public Session()
        {

        }
        public Session(int session_id, int program_id, int semester_id)
        {
            this.id = 0;
            this.program_id = 0;
            this.semester_id = 0;
        }
    }
}