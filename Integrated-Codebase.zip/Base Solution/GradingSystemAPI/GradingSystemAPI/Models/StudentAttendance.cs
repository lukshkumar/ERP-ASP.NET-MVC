﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GradingSystemAPI.Models
{
    public class StudentAttendance
    {
        public int id { get; set; }
        public DateTime date_time { get; set; }
        public int duration { get; set; }
        public string status { get; set; }
    }
}