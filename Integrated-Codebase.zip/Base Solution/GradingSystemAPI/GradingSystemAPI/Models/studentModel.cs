namespace CourseAnnouncement.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class studentModel : DbContext
    {
        public studentModel()
            : base("name=studentModel")
        {
        }

        public virtual DbSet<student> students { get; set; }
        /*
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<student>()
                .Property(e => e.roll)
                .IsUnicode(false);

            modelBuilder.Entity<student>()
                .Property(e => e.full_name)
                .IsUnicode(false);

            modelBuilder.Entity<student>()
                .Property(e => e.cnic)
                .IsUnicode(false);

            modelBuilder.Entity<student>()
                .Property(e => e.batch)
                .IsUnicode(false);

            modelBuilder.Entity<student>()
                .Property(e => e.email)
                .IsUnicode(false);
        }
        */
    }
}
