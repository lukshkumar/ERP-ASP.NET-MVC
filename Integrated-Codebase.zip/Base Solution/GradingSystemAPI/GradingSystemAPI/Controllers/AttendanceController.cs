﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using GradingSystemAPI.Models;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Collections;


namespace WebApplication.Controllers
{   
    public class AttendanceController : ApiController
    {
        public List<Semester> semester_List = new List<Semester>();
        public List<Course_Offered> courseOffered_List = new List<Course_Offered>();
        public List<Lecture> lecture_List = new List<Lecture>();
        public List<Program> program_List = new List<Program>();
        public List<Section_Offered> sectionOffer_List = new List<Section_Offered>();
        public List<Session> session_List = new List<Session>();

        public AttendanceController()
        {

        }
        // GET: Attendance
        [Route("api/Attendance/GetCampus")]
        public void GetIndex(string campus)
        {
            DataClassesDataContext context = new DataClassesDataContext();
            //context.course_offereds.InsertOnSubmit(courseOffered_List.ElementAt(0));
            context.SubmitChanges();
        }

        // get faculty list
        [Route("api/Attendance/getfaculty/")]
        public IHttpActionResult GetFaculty()
        {
            using (DataClassesDataContext context = new DataClassesDataContext())
            {
                IEnumerable<Faculty> faculty_details = context.ExecuteQuery<Faculty>("Select * from faculty").ToList();
                return Json(faculty_details);
            }
        }

        // get faculty
        [Route("api/Attendance/getfaculty/{name}")]
        public IHttpActionResult GetFaculty(string name)
        {
            using (DataClassesDataContext context = new DataClassesDataContext())
            {
                IEnumerable<Faculty> faculty_details = context.ExecuteQuery<Faculty>("Select * from faculty where name = {0}", name).ToList();
                return Json(faculty_details);
            }
        }

        // get courses
        [Route("api/Attendance/getcourses/{fac_id:int}")]
        public IHttpActionResult GetCourses(int fac_id)
        {
            List<Course> list = new List<Course>();
            using (DataClassesDataContext context = new DataClassesDataContext())
            {
                IEnumerable<Section_Offered> sections = context.ExecuteQuery<Section_Offered>("Select * from section_offered where faculty_id = {0}", fac_id).ToList();
                HashSet<int> course_ids = new HashSet<int>();
                foreach (var item in sections)
                {
                    int course_offered_id = item.course_offered_id;
                    IEnumerable<Course_Offered> course_offered = context.ExecuteQuery<Course_Offered>("Select * from course_offered where id = {0}", course_offered_id).ToList();
                    if (course_offered.Count() > 0)
                    {
                        Course_Offered obj = course_offered.ElementAt(0);
                        course_ids.Add(obj.course_id);
                    }

                }

                // finding course names
                foreach (var item in course_ids)
                {
                    IEnumerable<Course> course = context.ExecuteQuery<Course>("Select * from course where id = {0}", item).ToList();
                    list.Add(course.ElementAt(0));
                }

                return Json(list);

            }

        }

        //get section
        [Route("api/Attendance/getsection/{courseCode}/{facultyId}")]
        public IHttpActionResult GetSections(string courseCode, int facultyId)
        {


            List<Section_Offered> list = new List<Section_Offered>();
            using (DataClassesDataContext context = new DataClassesDataContext())
            {

                IEnumerable<Course> course_details = context.ExecuteQuery<Course>("Select * from course where code = {0}", courseCode).ToList();
                Course obj = course_details.ElementAt(0);

                IEnumerable<Course_Offered> course_offered = context.ExecuteQuery<Course_Offered>("Select * from course_offered where course_id = {0}", obj.id).ToList();

                foreach (var item in course_offered)
                {
                    int id = item.id;
                    IEnumerable<Section_Offered> section_offered = context.ExecuteQuery<Section_Offered>("Select * from section_offered where course_offered_id = {0} and faculty_id = {1}", id, facultyId).ToList();

                    foreach (var section in section_offered)
                    {
                        list.Add(section);
                    }
                }
                return Json(list);
            }
        }

        // Get Students
        [Route("api/Attendance/getstudent/{sectionId:int}")]
        public IHttpActionResult GetStudent(int sectionId)
        {
            List<Student> students = new List<Student>();
            using (DataClassesDataContext context = new DataClassesDataContext())
            {
                IEnumerable<Course_Registered> course_registered = context.ExecuteQuery<Course_Registered>("Select * from course_registered where section_offered_id = {0}", sectionId).ToList();
                foreach (var item in course_registered)
                {
                    IEnumerable<Student> student = context.ExecuteQuery<Student>("Select * from student where id = {0}", item.student_id).ToList();
                    Student stu = student.ElementAt(0);
                    students.Add(stu);
                }
            }
            return Json(students.OrderBy(x => x.roll).ToList());
        }

        //Get Lectures
        [Route("api/Attendance/getLectures/{sectionId:int}")]
        public IHttpActionResult GetLectures(int sectionId)
        {
            List<Student> students = new List<Student>();
            List<Lecture_Attend> lecture_attend = new List<Lecture_Attend>();

            using (DataClassesDataContext context = new DataClassesDataContext())
            {
                IEnumerable<Lecture> lectures = context.ExecuteQuery<Lecture>("Select id, date_time, section_offered_id, duration  from lecture where section_offered_id = {0}", sectionId).ToList();

                // findind students because we need roll no not id
                IEnumerable<Course_Registered> course_registered = context.ExecuteQuery<Course_Registered>("Select * from course_registered where section_offered_id = {0}", sectionId).ToList();
                foreach (var item in course_registered)
                {
                    IEnumerable<Student> student = context.ExecuteQuery<Student>("Select * from student where id = {0}", item.student_id).ToList();
                    Student stu = student.ElementAt(0);
                    students.Add(stu);
                }


                foreach (var lecture in lectures)
                {
                    IEnumerable<Attendance> Attendance_list_for_lecture = context.ExecuteQuery<Attendance>("Select * from attendance where lecture_id = {0}", lecture.id).ToList();

                    foreach (var item in Attendance_list_for_lecture)
                    {
                        foreach (var student in students)
                        {
                            if (student.id == item.student_id)
                            {
                                item.student_roll = student.roll;
                            }
                        }
                    }
                    // sorted by student roll number
                    List<Attendance> list = Attendance_list_for_lecture.OrderBy(x => x.student_roll).ToList();
                    Lecture_Attend data = new Lecture_Attend(lecture, list);
                    lecture_attend.Add(data);
                }
                return Json(lecture_attend);
            }
        }


        // Get Attendance  = if we use section id tou its means section already confrim hy kay kis course ka hay
        // tou section kay students bhi usi course kay hong gay

        // Update Attendance
        [HttpPost]
        [Route("api/Attendance/updateattendance")]
        public IHttpActionResult UpdateAttendance([FromBody] List<Attendance> AttendanceList)
        {
            using (DataClassesDataContext context = new DataClassesDataContext())
            {
                foreach (var item in AttendanceList)
                {
                    int rowEffected = context.ExecuteCommand("Update attendance set status = {0} where id = {1}", item.status, item.id);
                }

                Console.WriteLine(AttendanceList);

                return Ok(Json(AttendanceList));
            }
        }

        [HttpDelete]
        [Route("api/Attendance/deletelecture/{lec_id:int}")]
        public IHttpActionResult deletelecture(int lec_id)
        {
            using (DataClassesDataContext context = new DataClassesDataContext())
            {
                int count = context.ExecuteCommand("Delete from lecture where id = {0}", lec_id);
                Console.WriteLine(count);
                return Ok();
            }
        }


        [HttpPost]
        [Route("api/Attendance/AddLecture")]
        public IHttpActionResult AddLecture([FromBody] Lecture lec)
        {
            List<Student> students = new List<Student>();
            using (DataClassesDataContext context = new DataClassesDataContext())
            {
                int count = context.ExecuteCommand("insert into lecture (date_time , section_offered_id, duration)  values ({0},{1},{2})", lec.date_time, lec.section_offered_id, lec.duration);
                Console.WriteLine(count);



                IEnumerable<int> list = context.ExecuteQuery<int>("select top(1) id from lecture order by id desc");
                int id = list.ElementAt(0);

                // students
                IEnumerable<Course_Registered> course_registered = context.ExecuteQuery<Course_Registered>("Select * from course_registered where section_offered_id = {0}", lec.section_offered_id).ToList();
                foreach (var item in course_registered)
                {
                    IEnumerable<Student> student = context.ExecuteQuery<Student>("Select * from student where id = {0}", item.student_id).ToList();
                    Student stu = student.ElementAt(0);
                    students.Add(stu);
                }

                foreach (var student in students)
                {
                    // lecture id zero should be changed IMPORTANT
                    int row_count = context.ExecuteCommand("insert into attendance (status, lecture_id, student_id) values({0},{1},{2})", lec.defaultValue, id, student.id);
                }
                return Ok();
            }

        }

        [HttpPost]
        [Route("api/Attendance/FacultyLogin")]
        public IHttpActionResult Login([FromBody] Login login)
        {
            using (DataClassesDataContext context = new DataClassesDataContext())
            {
                IEnumerable<Faculty> faculty_details = context.ExecuteQuery<Faculty>("Select * from faculty where name = {0}", login.Name).ToList();
                return Json(faculty_details.ElementAt(0));
            }

        }


        [HttpGet]
        [Route("api/Attendance/getStudentSemester/{roll_no}")]
        public IHttpActionResult FetchSemesters(string roll_no)
        {
            using (DataClassesDataContext context = new DataClassesDataContext())
            {
                IEnumerable<Student> istudent = context.ExecuteQuery<Student>("Select * from student where roll = {0}", roll_no).ToList();
                Student student = istudent.ElementAt(0);

                IEnumerable<Course_Registered> course_Registereds = context.ExecuteQuery<Course_Registered>("Select * from course_registered where student_id = {0}", student.id).ToList();

                List<Course_Offered> course_Offereds = new List<Course_Offered>();
                foreach (var item in course_Registereds)
                {
                    IEnumerable<Course_Offered> course_off = context.ExecuteQuery<Course_Offered>("Select * from course_offered where id = {0} ", item.course_offered_id).ToList();
                    course_Offereds.Add(course_off.ElementAt(0));
                }


                List<Session> sessions = new List<Session>();
                foreach (var item in course_Offereds)
                {
                    IEnumerable<Session> session = context.ExecuteQuery<Session>("select * from session where id = {0}", item.session_id).ToList();
                    sessions.Add(session.ElementAt(0));
                }

                List<Semester> semesters = new List<Semester>();
                foreach (var item in sessions)
                {
                    IEnumerable<Semester> semester = context.ExecuteQuery<Semester>("Select * from semester where id = {0}", item.semester_id).ToList();
                    semesters.Add(semester.ElementAt(0));
                }

                return Json(semesters);
            }
        }


        [HttpGet]
        [Route("api/Attendance/getStudentAttendance/{roll_no}/{semester_id:int}")]
        public IHttpActionResult StudentAttendanceFetch(string roll_no, int semester_id)
        {
            StudentAttendanceData result = new StudentAttendanceData();
            StudentAttendance obj = new StudentAttendance();

            using (DataClassesDataContext context = new DataClassesDataContext())
            {
                // need student id from roll number
                IEnumerable<Student> istudent = context.ExecuteQuery<Student>("Select * from student where roll = {0}", roll_no).ToList();
                Student student = istudent.ElementAt(0);

                // finding session id
                IEnumerable<Session> sessions = context.ExecuteQuery<Session>("Select * from session where semester_id = {0}", semester_id).ToList();
                Session session = sessions.ElementAt(0);


                // finding all registered courses of student

                IEnumerable<int> registeredCourses = context.ExecuteQuery<int>("Select course_offered_id from course_registered where student_id = {0}", student.id).ToList();

                List<int> courses_ids = new List<int>();
                foreach (var item in registeredCourses)
                {
                    IEnumerable<int> id = context.ExecuteQuery<int>("Select course_id from course_offered where id = {0}", item).ToList();
                    courses_ids.Add(id.ElementAt(0));
                }

                // finding current session courses from all registered courses
                ArrayList sessionRegisteredCourses_ids = new ArrayList();
                foreach (var item in courses_ids)
                {
                    IEnumerable<int> currentSessionCourse_id = context.ExecuteQuery<int>("Select course_id from course_offered where session_id = {0} and course_id = {1}", session.id, item).ToList();
                    sessionRegisteredCourses_ids.Add(currentSessionCourse_id.ElementAt(0));
                }


                List<Course> courses = new List<Course>();
                foreach (var item in sessionRegisteredCourses_ids)
                {
                    IEnumerable<Course> course = context.ExecuteQuery<Course>("Select * from course where id = {0}", item).ToList();
                    courses.Add(course.ElementAt(0));
                }

                result.courses = courses;

                // need course offered ids of these courses
                List<int> courseOfferedIds_ofCurrentSemester = new List<int>();
                foreach (var item in courses)
                {
                    IEnumerable<int> ids = context.ExecuteQuery<int>("Select id from course_offered where course_id = {0} and session_id = {1}", item.id, session.id).ToList();
                    courseOfferedIds_ofCurrentSemester.Add(ids.ElementAt(0));
                }


                // section in which these courses offered
                List<int> sectionsIds = new List<int>();
                foreach (var courseOfferedId in courseOfferedIds_ofCurrentSemester)
                {
                    IEnumerable<int> section_offered_id = context.ExecuteQuery<int>("Select section_offered_id from course_registered where course_offered_id = {0} and student_id = {1}", courseOfferedId, student.id).ToList();
                    sectionsIds.Add(section_offered_id.ElementAt(0));
                }

                // lectures offered in thoses sections
                List<List<Lecture>> sections_lectures = new List<List<Lecture>>();
                foreach (var section in sectionsIds)
                {
                    IEnumerable<Lecture> lectures = context.ExecuteQuery<Lecture>("select * from lecture where section_offered_id = {0}", section).ToList();

                    List<Lecture> list = new List<Lecture>();
                    foreach (var item in lectures)
                    {
                        list.Add(item);
                    }
                    // lecture list of that particular section
                    sections_lectures.Add(list);
                }

                List<List<Attendance>> section_attendances = new List<List<Attendance>>();
                foreach (var lecturesOfSection in sections_lectures)
                {
                    // attendance of a particular section in which a course is offered
                    List<Attendance> attendanceOfSection = new List<Attendance>();
                    List<StudentAttendance> studentAttendance = new List<StudentAttendance>();

                    foreach (var item in lecturesOfSection)
                    {
                        StudentAttendance temp = new StudentAttendance();
                        temp.id = item.id;
                        temp.date_time = item.date_time;
                        temp.duration = item.duration;
                        // select lec_id, lec_date, duration, status from lecture, attendance where lec_id = atten_id, atten_std_id = , lec_iid =   
                        IEnumerable<Attendance> attendance = context.ExecuteQuery<Attendance>("Select * from attendance where lecture_id = {0} and student_id = {1}", item.id, student.id).ToList();
                        temp.status = attendance.ElementAt(0).status;

                        attendanceOfSection.Add(attendance.ElementAt(0));

                        studentAttendance.Add(temp);
                    }
                    section_attendances.Add(attendanceOfSection);

                    result.attendance.Add(studentAttendance);
                }

                return Json(result);
            }
        }


        [Route("api/Attendance/StudentLogin")]
        public IHttpActionResult AutheticateStudent([FromBody] StudentLogin login)
        {
            using (DataClassesDataContext context = new DataClassesDataContext())
            {
                IEnumerable<Student> student = context.ExecuteQuery<Student>("Select * from student where roll = {0}", login.roll).ToList();
                return Json(student.ElementAt(0));
            }
        }

    }
}