﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using CourseAnnouncement.Models;

namespace CourseAnnouncement.Controllers
{
    public class Course_AnnouncementController : ApiController
    {
        private DBModels db = new DBModels();

        // GET: api/Course_Announcement
        public IQueryable<Course_Announcement> GetCourse_Announcement()
        {
            return db.Course_Announcement;
        }

        // GET: api/Course_Announcement/5
        [ResponseType(typeof(Course_Announcement))]
        public IHttpActionResult GetCourse_Announcement(int id)
        {
            Course_Announcement course_Announcement = db.Course_Announcement.Find(id);
            if (course_Announcement == null)
            {
                return NotFound();
            }

            return Ok(course_Announcement);
        }

        // PUT: api/Course_Announcement/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutCourse_Announcement(int id, Course_Announcement course_Announcement)
        {
           

            if (id != course_Announcement.id)
            {
                return BadRequest();
            }

            db.Entry(course_Announcement).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Course_AnnouncementExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Course_Announcement
        [ResponseType(typeof(Course_Announcement))]
        public IHttpActionResult PostCourse_Announcement(Course_Announcement course_Announcement)
        {
            
            db.Course_Announcement.Add(course_Announcement);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = course_Announcement.id }, course_Announcement);
        }

        // DELETE: api/Course_Announcement/5
        [ResponseType(typeof(Course_Announcement))]
        public IHttpActionResult DeleteCourse_Announcement(int id)
        {
            Course_Announcement course_Announcement = db.Course_Announcement.Find(id);
            if (course_Announcement == null)
            {
                return NotFound();
            }

            db.Course_Announcement.Remove(course_Announcement);
            db.SaveChanges();

            return Ok(course_Announcement);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool Course_AnnouncementExists(int id)
        {
            return db.Course_Announcement.Count(e => e.id == id) > 0;
        }
    }
}